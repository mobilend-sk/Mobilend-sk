module.exports = {

"[project]/.next-internal/server/app/blog/[slug]/page/actions.js [app-rsc] (server actions loader, ecmascript)": ((__turbopack_context__) => {

var { m: module, e: exports } = __turbopack_context__;
{
}}),
"[project]/src/app/favicon.ico.mjs { IMAGE => \"[project]/src/app/favicon.ico (static in ecmascript)\" } [app-rsc] (structured image object, ecmascript, Next.js Server Component)": ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/src/app/favicon.ico.mjs { IMAGE => \"[project]/src/app/favicon.ico (static in ecmascript)\" } [app-rsc] (structured image object, ecmascript)"));
}),
"[project]/src/app/layout.js [app-rsc] (ecmascript, Next.js Server Component)": ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/src/app/layout.js [app-rsc] (ecmascript)"));
}),
"[externals]/fs [external] (fs, cjs)": ((__turbopack_context__) => {

var { m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("fs", () => require("fs"));

module.exports = mod;
}}),
"[externals]/buffer [external] (buffer, cjs)": ((__turbopack_context__) => {

var { m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("buffer", () => require("buffer"));

module.exports = mod;
}}),
"[project]/src/lib/blog.js [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

// src/lib/blog.js
// Серверные утилиты для работы с markdown файлами блога (ТОЛЬКО ДЛЯ СЕРВЕРА!)
__turbopack_context__.s({
    "createExcerpt": ()=>createExcerpt,
    "formatBlogDate": ()=>formatBlogDate,
    "getAllBlogFiles": ()=>getAllBlogFiles,
    "getAllBlogPosts": ()=>getAllBlogPosts,
    "getAllBlogSlugs": ()=>getAllBlogSlugs,
    "getBlogPost": ()=>getBlogPost,
    "getBlogPostBySlug": ()=>getBlogPostBySlug,
    "getRelatedBlogPosts": ()=>getRelatedBlogPosts,
    "markdownToHtml": ()=>markdownToHtml
});
var __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/fs [external] (fs, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/path [external] (path, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$gray$2d$matter$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/gray-matter/index.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$marked$2f$lib$2f$marked$2e$esm$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/marked/lib/marked.esm.js [app-rsc] (ecmascript)");
;
;
;
;
// Путь к папке с блог статьями
const BLOG_DIR = __TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__["default"].join(process.cwd(), 'public', 'data', 'blog', 'articles');
function formatBlogDate(dateString, locale = 'sk-SK') {
    if (!dateString) return '';
    try {
        const date = new Date(dateString);
        return date.toLocaleDateString(locale, {
            year: 'numeric',
            month: 'long',
            day: 'numeric'
        });
    } catch (error) {
        console.error('Ошибка форматирования даты:', error);
        return dateString;
    }
}
function createExcerpt(content, maxLength = 150) {
    if (!content) return '';
    // Убираем markdown разметку и HTML теги
    const plainText = content.replace(/#{1,6}\s+/g, '') // заголовки
    .replace(/\*\*(.*?)\*\*/g, '$1') // жирный текст
    .replace(/\*(.*?)\*/g, '$1') // курсив
    .replace(/\[(.*?)\]\(.*?\)/g, '$1') // ссылки
    .replace(/<[^>]*>/g, '') // HTML теги
    .trim();
    // Обрезаем до нужной длины
    if (plainText.length <= maxLength) return plainText;
    const truncated = plainText.substring(0, maxLength);
    const lastSpace = truncated.lastIndexOf(' ');
    return lastSpace > 0 ? truncated.substring(0, lastSpace) + '...' : truncated + '...';
}
function markdownToHtml(markdown) {
    if (!markdown) return '';
    try {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$marked$2f$lib$2f$marked$2e$esm$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["marked"])(markdown);
    } catch (error) {
        console.error('Ошибка рендера markdown:', error);
        return markdown;
    }
}
// Предобработка поста для компонентов
function processPostForComponents(post) {
    if (!post) return null;
    return {
        ...post,
        formattedDate: formatBlogDate(post.date),
        excerpt: post.description || createExcerpt(post.content, 120),
        htmlContent: markdownToHtml(post.content)
    };
}
// Проверяем существование папки блога
function ensureBlogDirExists() {
    if (!__TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__["default"].existsSync(BLOG_DIR)) {
        console.warn(`⚠️ Папка блога не найдена: ${BLOG_DIR}`);
        return false;
    }
    return true;
}
function getAllBlogFiles() {
    if (!ensureBlogDirExists()) return [];
    try {
        const files = __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__["default"].readdirSync(BLOG_DIR);
        return files.filter((file)=>file.endsWith('.md'));
    } catch (error) {
        console.error('Ошибка чтения папки блога:', error);
        return [];
    }
}
function getBlogPost(filename) {
    if (!ensureBlogDirExists()) return null;
    try {
        const filePath = __TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__["default"].join(BLOG_DIR, filename);
        if (!__TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__["default"].existsSync(filePath)) {
            console.warn(`⚠️ Файл не найден: ${filePath}`);
            return null;
        }
        const fileContent = __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__["default"].readFileSync(filePath, 'utf8');
        const { data, content } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$gray$2d$matter$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"])(fileContent);
        // Проверяем обязательные поля
        if (!data.title || !data.slug) {
            console.warn(`⚠️ Отсутствуют обязательные поля в ${filename}`);
            return null;
        }
        return {
            ...data,
            content,
            filename
        };
    } catch (error) {
        console.error(`Ошибка чтения файла ${filename}:`, error);
        return null;
    }
}
function getBlogPostBySlug(slug) {
    const files = getAllBlogFiles();
    for (const file of files){
        const post = getBlogPost(file);
        if (post && post.slug === slug) {
            return processPostForComponents(post);
        }
    }
    return null;
}
function getAllBlogPosts(limit = null) {
    const files = getAllBlogFiles();
    const posts = [];
    for (const file of files){
        const post = getBlogPost(file);
        if (post) {
            posts.push(processPostForComponents(post));
        }
    }
    // Сортируем по дате (новые сверху)
    posts.sort((a, b)=>{
        const dateA = new Date(a.date || 0);
        const dateB = new Date(b.date || 0);
        return dateB - dateA;
    });
    // Ограничиваем количество если нужно
    return limit ? posts.slice(0, limit) : posts;
}
function getAllBlogSlugs() {
    const posts = getAllBlogPosts();
    return posts.map((post)=>post.slug).filter(Boolean);
}
function getRelatedBlogPosts(currentSlug, limit = 4) {
    const allPosts = getAllBlogPosts();
    // Исключаем текущую статью
    const relatedPosts = allPosts.filter((post)=>post.slug !== currentSlug);
    // Возвращаем ограниченное количество
    return relatedPosts.slice(0, limit);
}
}),
"[project]/src/components/BlogContent/BlogContent.jsx [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

// src/components/BlogContent/BlogContent.jsx
// Компонент для рендера markdown контента статьи
__turbopack_context__.s({
    "default": ()=>__TURBOPACK__default__export__
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
;
;
const BlogContent = ({ post })=>{
    if (!post) return null;
    const { title, date, author, categories = [], image, description, htmlContent, formattedDate// Уже отформатированная дата приходит с сервера
     } = post;
    const imageUrl = image || '/images/blog/default-blog.jpg';
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("article", {
        className: "BlogContent",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("header", {
                className: "BlogContent__header",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "BlogContent__meta",
                        children: [
                            categories.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "BlogContent__categories",
                                children: categories.map((category, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "BlogContent__category",
                                        children: category
                                    }, index, false, {
                                        fileName: "[project]/src/components/BlogContent/BlogContent.jsx",
                                        lineNumber: 31,
                                        columnNumber: 9
                                    }, ("TURBOPACK compile-time value", void 0)))
                            }, void 0, false, {
                                fileName: "[project]/src/components/BlogContent/BlogContent.jsx",
                                lineNumber: 29,
                                columnNumber: 7
                            }, ("TURBOPACK compile-time value", void 0)),
                            formattedDate && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("time", {
                                className: "BlogContent__date",
                                dateTime: date,
                                children: formattedDate
                            }, void 0, false, {
                                fileName: "[project]/src/components/BlogContent/BlogContent.jsx",
                                lineNumber: 39,
                                columnNumber: 7
                            }, ("TURBOPACK compile-time value", void 0)),
                            author && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "BlogContent__author",
                                children: author
                            }, void 0, false, {
                                fileName: "[project]/src/components/BlogContent/BlogContent.jsx",
                                lineNumber: 44,
                                columnNumber: 7
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/BlogContent/BlogContent.jsx",
                        lineNumber: 27,
                        columnNumber: 5
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                        className: "BlogContent__title",
                        children: title
                    }, void 0, false, {
                        fileName: "[project]/src/components/BlogContent/BlogContent.jsx",
                        lineNumber: 51,
                        columnNumber: 5
                    }, ("TURBOPACK compile-time value", void 0)),
                    description && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "BlogContent__description",
                        children: description
                    }, void 0, false, {
                        fileName: "[project]/src/components/BlogContent/BlogContent.jsx",
                        lineNumber: 57,
                        columnNumber: 6
                    }, ("TURBOPACK compile-time value", void 0)),
                    imageUrl && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "BlogContent__hero-image",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                            src: imageUrl,
                            alt: title,
                            className: "BlogContent__hero-img"
                        }, void 0, false, {
                            fileName: "[project]/src/components/BlogContent/BlogContent.jsx",
                            lineNumber: 65,
                            columnNumber: 7
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/src/components/BlogContent/BlogContent.jsx",
                        lineNumber: 64,
                        columnNumber: 6
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/BlogContent/BlogContent.jsx",
                lineNumber: 25,
                columnNumber: 4
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "BlogContent__body",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "BlogContent__prose",
                    dangerouslySetInnerHTML: {
                        __html: htmlContent
                    }
                }, void 0, false, {
                    fileName: "[project]/src/components/BlogContent/BlogContent.jsx",
                    lineNumber: 76,
                    columnNumber: 5
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/src/components/BlogContent/BlogContent.jsx",
                lineNumber: 75,
                columnNumber: 4
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/BlogContent/BlogContent.jsx",
        lineNumber: 23,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0));
};
const __TURBOPACK__default__export__ = BlogContent;
}),
"[project]/src/components/BlogSlider/BlogSlider.jsx [app-rsc] (client reference proxy) <module evaluation>": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "default": ()=>__TURBOPACK__default__export__
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call the default export of [project]/src/components/BlogSlider/BlogSlider.jsx <module evaluation> from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/src/components/BlogSlider/BlogSlider.jsx <module evaluation>", "default");
}),
"[project]/src/components/BlogSlider/BlogSlider.jsx [app-rsc] (client reference proxy)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "default": ()=>__TURBOPACK__default__export__
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call the default export of [project]/src/components/BlogSlider/BlogSlider.jsx from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/src/components/BlogSlider/BlogSlider.jsx", "default");
}),
"[project]/src/components/BlogSlider/BlogSlider.jsx [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$BlogSlider$2f$BlogSlider$2e$jsx__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/src/components/BlogSlider/BlogSlider.jsx [app-rsc] (client reference proxy) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$BlogSlider$2f$BlogSlider$2e$jsx__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__ = __turbopack_context__.i("[project]/src/components/BlogSlider/BlogSlider.jsx [app-rsc] (client reference proxy)");
;
__turbopack_context__.n(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$BlogSlider$2f$BlogSlider$2e$jsx__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__);
}),
"[project]/src/components/SEO/JsonLdSchemas.js [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

// src/components/SEO/JsonLdSchemas.js
// JSON-LD схемы для лучшего SEO
// 1. Схема для товара (Product Schema)
__turbopack_context__.s({
    "generateBreadcrumbSchema": ()=>generateBreadcrumbSchema,
    "generateLocalBusinessSchema": ()=>generateLocalBusinessSchema,
    "generateOrganizationSchema": ()=>generateOrganizationSchema,
    "generateProductSchema": ()=>generateProductSchema,
    "generateWebsiteSchema": ()=>generateWebsiteSchema
});
function generateProductSchema(product) {
    if (!product) return null;
    const baseUrl = ("TURBOPACK compile-time value", "https://mobilend.sk") || 'https://mobilend.sk';
    // Рассчитываем цену со скидкой
    const originalPrice = parseFloat(product.price) || 0;
    const discount = parseFloat(product.discount) || 0;
    const currentPrice = discount > 0 ? originalPrice * (1 - discount / 100) : originalPrice;
    // Определяем изображение
    let productImage = null;
    if (product.mainImage) {
        productImage = `${baseUrl}/data/gallery/${product.mainImage}`;
    } else if (product.images && product.images.length > 0 && !product.images[0].startsWith('http')) {
        productImage = `${baseUrl}/data/gallery/${product.images[0]}`;
    }
    const schema = {
        "@context": "https://schema.org/",
        "@type": "Product",
        "name": product.model,
        "description": product.shortInfo || `${product.model} s ${product.memory || 'rôznou'} pamäťou. Kvalitný mobilný telefón s modernou technológiou.`,
        "brand": {
            "@type": "Brand",
            "name": product.modelGroup === "Iphones" ? "Apple" : product.modelGroup.replace(" Galaxy", "") || "Apple"
        },
        "category": "Mobilné telefóny",
        "sku": product.productLink,
        "url": `${baseUrl}/katalog/${product.productLink}`,
        "image": productImage ? [
            productImage
        ] : [],
        // Цена и наличие
        "offers": {
            "@type": "Offer",
            "price": currentPrice.toFixed(2),
            "priceCurrency": "EUR",
            "priceValidUntil": new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
            "availability": "https://schema.org/InStock",
            "url": `${baseUrl}/katalog/${product.productLink}`,
            "seller": {
                "@type": "Organization",
                "name": "Mobilend",
                "url": baseUrl
            }
        },
        // Дополнительные свойства товара
        "additionalProperty": []
    };
    // Добавляем характеристики если есть
    if (product.memory) {
        schema.additionalProperty.push({
            "@type": "PropertyValue",
            "name": "Pamäť",
            "value": product.memory
        });
    }
    if (product.color) {
        schema.additionalProperty.push({
            "@type": "PropertyValue",
            "name": "Farba",
            "value": product.color
        });
    }
    return JSON.stringify(schema);
}
function generateOrganizationSchema() {
    const baseUrl = ("TURBOPACK compile-time value", "https://mobilend.sk") || 'https://mobilend.sk';
    const schema = {
        "@context": "https://schema.org",
        "@type": "Organization",
        "name": "Mobilend",
        "alternateName": "Mobilend.sk",
        "description": "Predajca mobilných telefónov na Slovensku. Široký výber iPhone, Samsung Galaxy a ďalších značiek za najlepšie ceny.",
        "url": baseUrl,
        "logo": `${baseUrl}/images/logo.png`,
        "image": `${baseUrl}/images/og-homepage.jpg`,
        // Контактная информация
        "contactPoint": {
            "@type": "ContactPoint",
            "telephone": "+421919496013",
            "contactType": "customer service",
            "email": "zl.maildesk@gmail.com",
            "availableLanguage": [
                "Slovak"
            ]
        },
        // Адрес
        "address": {
            "@type": "PostalAddress",
            "streetAddress": "Pekná cesta 2459",
            "addressLocality": "Bratislava",
            "addressRegion": "Bratislavský kraj",
            "postalCode": "831 52",
            "addressCountry": "SK"
        },
        // Социальные сети (если есть)
        "sameAs": [],
        // Область деятельности
        "knowsAbout": [
            "mobilné telefóny",
            "smartfóny",
            "iPhone",
            "Samsung Galaxy",
            "elektronika"
        ]
    };
    return JSON.stringify(schema);
}
function generateLocalBusinessSchema() {
    const baseUrl = ("TURBOPACK compile-time value", "https://mobilend.sk") || 'https://mobilend.sk';
    const schema = {
        "@context": "https://schema.org",
        "@type": "ElectronicsStore",
        "name": "Mobilend",
        "description": "Obchod s mobilnými telefónmi v Bratislave. Predaj iPhone, Samsung Galaxy a ďalších značiek.",
        "url": baseUrl,
        "telephone": "+421919496013",
        "email": "zl.maildesk@gmail.com",
        // Адрес и геолокация
        "address": {
            "@type": "PostalAddress",
            "streetAddress": "Pekná cesta 2459",
            "addressLocality": "Bratislava",
            "addressRegion": "Rača",
            "postalCode": "831 52",
            "addressCountry": "SK"
        },
        "geo": {
            "@type": "GeoCoordinates",
            "latitude": "48.198111",
            "longitude": "17.135069"
        },
        // Часы работы (настрой под свои)
        "openingHoursSpecification": [
            {
                "@type": "OpeningHoursSpecification",
                "dayOfWeek": [
                    "Monday",
                    "Tuesday",
                    "Wednesday",
                    "Thursday",
                    "Friday"
                ],
                "opens": "09:00",
                "closes": "18:00"
            },
            {
                "@type": "OpeningHoursSpecification",
                "dayOfWeek": "Saturday",
                "opens": "09:00",
                "closes": "16:00"
            }
        ],
        // Способы оплаты
        "paymentAccepted": [
            "Cash",
            "Credit Card",
            "Bank Transfer"
        ],
        // Область обслуживания
        "areaServed": {
            "@type": "Country",
            "name": "Slovakia"
        },
        // Что продаем
        "hasOfferCatalog": {
            "@type": "OfferCatalog",
            "name": "Mobilné telefóny",
            "itemListElement": [
                {
                    "@type": "Offer",
                    "itemOffered": {
                        "@type": "Product",
                        "name": "iPhone"
                    }
                },
                {
                    "@type": "Offer",
                    "itemOffered": {
                        "@type": "Product",
                        "name": "Samsung Galaxy"
                    }
                }
            ]
        }
    };
    return JSON.stringify(schema);
}
function generateWebsiteSchema() {
    const baseUrl = ("TURBOPACK compile-time value", "https://mobilend.sk") || 'https://mobilend.sk';
    const schema = {
        "@context": "https://schema.org",
        "@type": "WebSite",
        "name": "Mobilend",
        "alternateName": "Mobilend.sk",
        "url": baseUrl,
        "description": "Mobilné telefóny za najlepšie ceny na Slovensku",
        // Поиск по сайту (если есть функция поиска)
        "potentialAction": {
            "@type": "SearchAction",
            "target": {
                "@type": "EntryPoint",
                "urlTemplate": `${baseUrl}/katalog?search={search_term_string}`
            },
            "query-input": "required name=search_term_string"
        },
        // Издатель
        "publisher": {
            "@type": "Organization",
            "name": "Mobilend",
            "url": baseUrl
        }
    };
    return JSON.stringify(schema);
}
function generateBreadcrumbSchema(breadcrumbs) {
    if (!breadcrumbs || breadcrumbs.length === 0) return null;
    const baseUrl = ("TURBOPACK compile-time value", "https://mobilend.sk") || 'https://mobilend.sk';
    const schema = {
        "@context": "https://schema.org",
        "@type": "BreadcrumbList",
        "itemListElement": breadcrumbs.map((crumb, index)=>({
                "@type": "ListItem",
                "position": index + 1,
                "name": crumb.name,
                "item": `${baseUrl}${crumb.url}`
            }))
    };
    return JSON.stringify(schema);
}
}),
"[project]/src/components/SEO/JsonLd.jsx [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

// src/components/SEO/JsonLd.jsx
// Компонент для рендера JSON-LD схем в <head>
__turbopack_context__.s({
    "MultipleJsonLd": ()=>MultipleJsonLd,
    "default": ()=>__TURBOPACK__default__export__
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$components$2f$noop$2d$head$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/components/noop-head.js [app-rsc] (ecmascript)");
;
;
const JsonLd = ({ schema })=>{
    if (!schema) return null;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$components$2f$noop$2d$head$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("script", {
            type: "application/ld+json",
            dangerouslySetInnerHTML: {
                __html: schema
            }
        }, void 0, false, {
            fileName: "[project]/src/components/SEO/JsonLd.jsx",
            lineNumber: 11,
            columnNumber: 4
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/src/components/SEO/JsonLd.jsx",
        lineNumber: 10,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0));
};
const MultipleJsonLd = ({ schemas })=>{
    if (!schemas || schemas.length === 0) return null;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$components$2f$noop$2d$head$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
        children: schemas.map((schema, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("script", {
                type: "application/ld+json",
                dangerouslySetInnerHTML: {
                    __html: schema
                }
            }, index, false, {
                fileName: "[project]/src/components/SEO/JsonLd.jsx",
                lineNumber: 26,
                columnNumber: 5
            }, ("TURBOPACK compile-time value", void 0)))
    }, void 0, false, {
        fileName: "[project]/src/components/SEO/JsonLd.jsx",
        lineNumber: 24,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0));
};
const __TURBOPACK__default__export__ = JsonLd;
}),
"[project]/src/pages/ArticlePage/ArticlePage.jsx [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

// src/pages/ArticlePage/ArticlePage.jsx
// Компонент страницы отдельной статьи блога
__turbopack_context__.s({
    "default": ()=>__TURBOPACK__default__export__
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$BlogContent$2f$BlogContent$2e$jsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/BlogContent/BlogContent.jsx [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$BlogSlider$2f$BlogSlider$2e$jsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/BlogSlider/BlogSlider.jsx [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$SEO$2f$JsonLdSchemas$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/SEO/JsonLdSchemas.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$SEO$2f$JsonLd$2e$jsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/SEO/JsonLd.jsx [app-rsc] (ecmascript)");
;
;
;
;
;
;
// Генерация JSON-LD схемы для статьи
function generateArticleSchema(post) {
    if (!post) return null;
    const baseUrl = ("TURBOPACK compile-time value", "https://mobilend.sk") || 'https://mobilend.sk';
    const imageUrl = post.image ? `${baseUrl}${post.image}` : `${baseUrl}/images/blog/default-blog.jpg`;
    const schema = {
        "@context": "https://schema.org",
        "@type": "Article",
        "headline": post.title,
        "description": post.description || post.title,
        "image": [
            imageUrl
        ],
        "datePublished": post.date,
        "dateModified": post.date,
        "author": {
            "@type": "Person",
            "name": post.author || "Mobilend"
        },
        "publisher": {
            "@type": "Organization",
            "name": "Mobilend",
            "logo": {
                "@type": "ImageObject",
                "url": `${baseUrl}/images/logo.png`
            }
        },
        "mainEntityOfPage": {
            "@type": "WebPage",
            "@id": `${baseUrl}/blog/${post.slug}`
        },
        "articleSection": post.categories ? post.categories.join(", ") : "Technology",
        "keywords": post.categories ? post.categories.join(", ") : "",
        "wordCount": post.content ? post.content.split(' ').length : 0
    };
    return JSON.stringify(schema);
}
const ArticlePage = ({ post, relatedPosts = [] })=>{
    if (!post) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "ArticlePage",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "container",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "ArticlePage__not-found",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                            children: "Článok sa nenašiel"
                        }, void 0, false, {
                            fileName: "[project]/src/pages/ArticlePage/ArticlePage.jsx",
                            lineNumber: 57,
                            columnNumber: 7
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            children: "Možno je odkaz nesprávny alebo bol článok odstránený"
                        }, void 0, false, {
                            fileName: "[project]/src/pages/ArticlePage/ArticlePage.jsx",
                            lineNumber: 58,
                            columnNumber: 7
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                            href: "/blog",
                            className: "ArticlePage__back-button",
                            children: "Prejsť na blog"
                        }, void 0, false, {
                            fileName: "[project]/src/pages/ArticlePage/ArticlePage.jsx",
                            lineNumber: 59,
                            columnNumber: 7
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/pages/ArticlePage/ArticlePage.jsx",
                    lineNumber: 56,
                    columnNumber: 6
                }, ("TURBOPACK compile-time value", void 0))
            }, void 0, false, {
                fileName: "[project]/src/pages/ArticlePage/ArticlePage.jsx",
                lineNumber: 55,
                columnNumber: 5
            }, ("TURBOPACK compile-time value", void 0))
        }, void 0, false, {
            fileName: "[project]/src/pages/ArticlePage/ArticlePage.jsx",
            lineNumber: 54,
            columnNumber: 4
        }, ("TURBOPACK compile-time value", void 0));
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("main", {
        className: "ArticlePage",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$SEO$2f$JsonLd$2e$jsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                schema: generateArticleSchema(post)
            }, void 0, false, {
                fileName: "[project]/src/pages/ArticlePage/ArticlePage.jsx",
                lineNumber: 71,
                columnNumber: 4
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$SEO$2f$JsonLd$2e$jsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                schema: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$SEO$2f$JsonLdSchemas$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["generateBreadcrumbSchema"])([
                    {
                        name: 'Domov',
                        url: '/'
                    },
                    {
                        name: 'Blog',
                        url: '/blog'
                    },
                    {
                        name: post.title,
                        url: `/blog/${post.slug}`
                    }
                ])
            }, void 0, false, {
                fileName: "[project]/src/pages/ArticlePage/ArticlePage.jsx",
                lineNumber: 72,
                columnNumber: 4
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "container",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("nav", {
                        className: "ArticlePage__breadcrumbs",
                        "aria-label": "Breadcrumb",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("ol", {
                            className: "breadcrumb-list",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                    className: "breadcrumb-item",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                        href: "/",
                                        children: "Hlavná"
                                    }, void 0, false, {
                                        fileName: "[project]/src/pages/ArticlePage/ArticlePage.jsx",
                                        lineNumber: 83,
                                        columnNumber: 8
                                    }, ("TURBOPACK compile-time value", void 0))
                                }, void 0, false, {
                                    fileName: "[project]/src/pages/ArticlePage/ArticlePage.jsx",
                                    lineNumber: 82,
                                    columnNumber: 7
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                    className: "breadcrumb-item",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                        href: "/blog",
                                        children: "Blog"
                                    }, void 0, false, {
                                        fileName: "[project]/src/pages/ArticlePage/ArticlePage.jsx",
                                        lineNumber: 86,
                                        columnNumber: 8
                                    }, ("TURBOPACK compile-time value", void 0))
                                }, void 0, false, {
                                    fileName: "[project]/src/pages/ArticlePage/ArticlePage.jsx",
                                    lineNumber: 85,
                                    columnNumber: 7
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                    className: "breadcrumb-item active",
                                    "aria-current": "page",
                                    children: post.title
                                }, void 0, false, {
                                    fileName: "[project]/src/pages/ArticlePage/ArticlePage.jsx",
                                    lineNumber: 88,
                                    columnNumber: 7
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/pages/ArticlePage/ArticlePage.jsx",
                            lineNumber: 81,
                            columnNumber: 6
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/src/pages/ArticlePage/ArticlePage.jsx",
                        lineNumber: 80,
                        columnNumber: 5
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$BlogContent$2f$BlogContent$2e$jsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        post: post
                    }, void 0, false, {
                        fileName: "[project]/src/pages/ArticlePage/ArticlePage.jsx",
                        lineNumber: 95,
                        columnNumber: 5
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/pages/ArticlePage/ArticlePage.jsx",
                lineNumber: 78,
                columnNumber: 4
            }, ("TURBOPACK compile-time value", void 0)),
            relatedPosts.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$BlogSlider$2f$BlogSlider$2e$jsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                posts: relatedPosts,
                title: "Mohli by vás zaujímať",
                subtitle: "Podobné články z nášho blogu",
                className: "ArticlePage__related",
                cardVariant: "compact",
                slidesToShow: 3,
                autoplay: false
            }, void 0, false, {
                fileName: "[project]/src/pages/ArticlePage/ArticlePage.jsx",
                lineNumber: 100,
                columnNumber: 5
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/src/pages/ArticlePage/ArticlePage.jsx",
        lineNumber: 69,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0));
};
const __TURBOPACK__default__export__ = ArticlePage;
}),
"[project]/src/app/blog/[slug]/page.js [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

// src/app/blog/[slug]/page.js
// Страница отдельной статьи блога - только данные и метаданные
__turbopack_context__.s({
    "default": ()=>BlogPost,
    "generateMetadata": ()=>generateMetadata,
    "generateStaticParams": ()=>generateStaticParams,
    "revalidate": ()=>revalidate
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$api$2f$navigation$2e$react$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/next/dist/api/navigation.react-server.js [app-rsc] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$components$2f$navigation$2e$react$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/components/navigation.react-server.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$blog$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/blog.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$pages$2f$ArticlePage$2f$ArticlePage$2e$jsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/pages/ArticlePage/ArticlePage.jsx [app-rsc] (ecmascript)");
;
;
;
;
const revalidate = 3600;
async function generateStaticParams() {
    try {
        console.log('🔄 Генерируем статические пути для блог статей...');
        const slugs = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$blog$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["getAllBlogSlugs"])() // Убираем await
        ;
        console.log(`✅ Найдено ${slugs.length} блог статей для генерации`);
        return slugs.map((slug)=>({
                slug: slug
            }));
    } catch (error) {
        console.error('❌ Ошибка генерации статических путей блога:', error);
        return [];
    }
}
async function generateMetadata({ params }) {
    try {
        const { slug } = await params;
        const post = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$blog$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["getBlogPostBySlug"])(slug) // Убираем await
        ;
        if (!post) {
            return {
                title: 'Článok sa nenašiel - Mobilend Blog',
                description: 'Požadovaný článok sa nenašiel v našom blogu.'
            };
        }
        // Определяем изображение для OpenGraph
        const baseUrl = ("TURBOPACK compile-time value", "https://mobilend.sk") || 'https://mobilend.sk';
        const ogImage = post.image ? `${baseUrl}${post.image}` : `${baseUrl}/images/blog/default-blog.jpg`;
        return {
            title: `${post.title} | Mobilend Blog`,
            description: post.description || post.title,
            keywords: post.categories || [],
            // Open Graph теги
            openGraph: {
                title: post.title,
                description: post.description || post.title,
                type: 'article',
                url: `${baseUrl}/blog/${slug}`,
                siteName: 'Mobilend',
                locale: 'sk_SK',
                images: [
                    {
                        url: ogImage,
                        width: 1200,
                        height: 630,
                        alt: post.title
                    }
                ],
                publishedTime: post.date,
                authors: [
                    post.author || 'Mobilend'
                ],
                section: post.categories ? post.categories[0] : 'Technology',
                tags: post.categories || []
            },
            // Twitter Card
            twitter: {
                card: 'summary_large_image',
                title: post.title,
                description: post.description || post.title,
                images: [
                    ogImage
                ],
                creator: '@mobilend_sk'
            },
            // Article теги
            other: {
                'article:published_time': post.date,
                'article:author': post.author || 'Mobilend',
                'article:section': post.categories ? post.categories[0] : 'Technology',
                'article:tag': post.categories ? post.categories.join(', ') : ''
            },
            // Robots
            robots: {
                index: true,
                follow: true,
                googleBot: {
                    index: true,
                    follow: true,
                    'max-video-preview': -1,
                    'max-image-preview': 'large',
                    'max-snippet': -1
                }
            },
            // Canonical URL
            alternates: {
                canonical: `/blog/${slug}`
            }
        };
    } catch (error) {
        console.error('Ошибка генерации метаданных для статьи:', error);
        return {
            title: 'Chyba načítania článku - Mobilend Blog'
        };
    }
}
async function BlogPost({ params }) {
    try {
        const { slug } = await params;
        // Получаем статью по slug
        const post = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$blog$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["getBlogPostBySlug"])(slug) // Убираем await
        ;
        // Если статья не найдена - показываем 404
        if (!post) {
            console.warn(`Статья с slug "${slug}" не найдена`);
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$components$2f$navigation$2e$react$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["notFound"])();
        }
        // Получаем похожие статьи (исключаем текущую)
        const relatedPosts = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$blog$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["getRelatedBlogPosts"])(slug, 4) // Убираем await
        ;
        // Передаем данные в компонент
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$pages$2f$ArticlePage$2f$ArticlePage$2e$jsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
            post: post,
            relatedPosts: relatedPosts
        }, void 0, false, {
            fileName: "[project]/src/app/blog/[slug]/page.js",
            lineNumber: 136,
            columnNumber: 10
        }, this);
    } catch (error) {
        console.error('Ошибка загрузки страницы статьи:', error);
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$components$2f$navigation$2e$react$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["notFound"])();
    }
}
}),
"[project]/src/app/blog/[slug]/page.js [app-rsc] (ecmascript, Next.js Server Component)": ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/src/app/blog/[slug]/page.js [app-rsc] (ecmascript)"));
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)": ((__turbopack_context__) => {

var { m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}}),

};

//# sourceMappingURL=%5Broot-of-the-server%5D__41ea06ec._.js.map