module.exports = {

"[project]/.next-internal/server/app/blog/page/actions.js [app-rsc] (server actions loader, ecmascript)": ((__turbopack_context__) => {

var { m: module, e: exports } = __turbopack_context__;
{
}}),
"[project]/src/app/favicon.ico.mjs { IMAGE => \"[project]/src/app/favicon.ico (static in ecmascript)\" } [app-rsc] (structured image object, ecmascript, Next.js Server Component)": ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/src/app/favicon.ico.mjs { IMAGE => \"[project]/src/app/favicon.ico (static in ecmascript)\" } [app-rsc] (structured image object, ecmascript)"));
}),
"[project]/src/app/layout.js [app-rsc] (ecmascript, Next.js Server Component)": ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/src/app/layout.js [app-rsc] (ecmascript)"));
}),
"[externals]/fs [external] (fs, cjs)": ((__turbopack_context__) => {

var { m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("fs", () => require("fs"));

module.exports = mod;
}}),
"[externals]/buffer [external] (buffer, cjs)": ((__turbopack_context__) => {

var { m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("buffer", () => require("buffer"));

module.exports = mod;
}}),
"[project]/src/lib/blog.js [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

// src/lib/blog.js
// Серверные утилиты для работы с markdown файлами блога (ТОЛЬКО ДЛЯ СЕРВЕРА!)
__turbopack_context__.s({
    "createExcerpt": ()=>createExcerpt,
    "formatBlogDate": ()=>formatBlogDate,
    "getAllBlogFiles": ()=>getAllBlogFiles,
    "getAllBlogPosts": ()=>getAllBlogPosts,
    "getAllBlogSlugs": ()=>getAllBlogSlugs,
    "getBlogPost": ()=>getBlogPost,
    "getBlogPostBySlug": ()=>getBlogPostBySlug,
    "getRelatedBlogPosts": ()=>getRelatedBlogPosts,
    "markdownToHtml": ()=>markdownToHtml
});
var __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/fs [external] (fs, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/path [external] (path, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$gray$2d$matter$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/gray-matter/index.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$marked$2f$lib$2f$marked$2e$esm$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/marked/lib/marked.esm.js [app-rsc] (ecmascript)");
;
;
;
;
// Путь к папке с блог статьями
const BLOG_DIR = __TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__["default"].join(process.cwd(), 'public', 'data', 'blog', 'articles');
function formatBlogDate(dateString, locale = 'sk-SK') {
    if (!dateString) return '';
    try {
        const date = new Date(dateString);
        return date.toLocaleDateString(locale, {
            year: 'numeric',
            month: 'long',
            day: 'numeric'
        });
    } catch (error) {
        console.error('Ошибка форматирования даты:', error);
        return dateString;
    }
}
function createExcerpt(content, maxLength = 150) {
    if (!content) return '';
    // Убираем markdown разметку и HTML теги
    const plainText = content.replace(/#{1,6}\s+/g, '') // заголовки
    .replace(/\*\*(.*?)\*\*/g, '$1') // жирный текст
    .replace(/\*(.*?)\*/g, '$1') // курсив
    .replace(/\[(.*?)\]\(.*?\)/g, '$1') // ссылки
    .replace(/<[^>]*>/g, '') // HTML теги
    .trim();
    // Обрезаем до нужной длины
    if (plainText.length <= maxLength) return plainText;
    const truncated = plainText.substring(0, maxLength);
    const lastSpace = truncated.lastIndexOf(' ');
    return lastSpace > 0 ? truncated.substring(0, lastSpace) + '...' : truncated + '...';
}
function markdownToHtml(markdown) {
    if (!markdown) return '';
    try {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$marked$2f$lib$2f$marked$2e$esm$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["marked"])(markdown);
    } catch (error) {
        console.error('Ошибка рендера markdown:', error);
        return markdown;
    }
}
// Предобработка поста для компонентов
function processPostForComponents(post) {
    if (!post) return null;
    return {
        ...post,
        formattedDate: formatBlogDate(post.date),
        excerpt: post.description || createExcerpt(post.content, 120),
        htmlContent: markdownToHtml(post.content)
    };
}
// Проверяем существование папки блога
function ensureBlogDirExists() {
    if (!__TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__["default"].existsSync(BLOG_DIR)) {
        console.warn(`⚠️ Папка блога не найдена: ${BLOG_DIR}`);
        return false;
    }
    return true;
}
function getAllBlogFiles() {
    if (!ensureBlogDirExists()) return [];
    try {
        const files = __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__["default"].readdirSync(BLOG_DIR);
        return files.filter((file)=>file.endsWith('.md'));
    } catch (error) {
        console.error('Ошибка чтения папки блога:', error);
        return [];
    }
}
function getBlogPost(filename) {
    if (!ensureBlogDirExists()) return null;
    try {
        const filePath = __TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__["default"].join(BLOG_DIR, filename);
        if (!__TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__["default"].existsSync(filePath)) {
            console.warn(`⚠️ Файл не найден: ${filePath}`);
            return null;
        }
        const fileContent = __TURBOPACK__imported__module__$5b$externals$5d2f$fs__$5b$external$5d$__$28$fs$2c$__cjs$29$__["default"].readFileSync(filePath, 'utf8');
        const { data, content } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$gray$2d$matter$2f$index$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"])(fileContent);
        // Проверяем обязательные поля
        if (!data.title || !data.slug) {
            console.warn(`⚠️ Отсутствуют обязательные поля в ${filename}`);
            return null;
        }
        return {
            ...data,
            content,
            filename
        };
    } catch (error) {
        console.error(`Ошибка чтения файла ${filename}:`, error);
        return null;
    }
}
function getBlogPostBySlug(slug) {
    const files = getAllBlogFiles();
    for (const file of files){
        const post = getBlogPost(file);
        if (post && post.slug === slug) {
            return processPostForComponents(post);
        }
    }
    return null;
}
function getAllBlogPosts(limit = null) {
    const files = getAllBlogFiles();
    const posts = [];
    for (const file of files){
        const post = getBlogPost(file);
        if (post) {
            posts.push(processPostForComponents(post));
        }
    }
    // Сортируем по дате (новые сверху)
    posts.sort((a, b)=>{
        const dateA = new Date(a.date || 0);
        const dateB = new Date(b.date || 0);
        return dateB - dateA;
    });
    // Ограничиваем количество если нужно
    return limit ? posts.slice(0, limit) : posts;
}
function getAllBlogSlugs() {
    const posts = getAllBlogPosts();
    return posts.map((post)=>post.slug).filter(Boolean);
}
function getRelatedBlogPosts(currentSlug, limit = 4) {
    const allPosts = getAllBlogPosts();
    // Исключаем текущую статью
    const relatedPosts = allPosts.filter((post)=>post.slug !== currentSlug);
    // Возвращаем ограниченное количество
    return relatedPosts.slice(0, limit);
}
}),
"[project]/src/components/BlogCard/BlogCard.jsx [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

// src/components/BlogCard/BlogCard.jsx
// Карточка статьи блога
__turbopack_context__.s({
    "default": ()=>__TURBOPACK__default__export__
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-rsc] (ecmascript)");
;
;
;
;
const BlogCard = ({ post, className = '', priority = false })=>{
    if (!post) return null;
    const { title, description, slug, date, image, author, categories = [], excerpt, formattedDate// Уже отформатированная дата приходит с сервера
     } = post;
    const imageUrl = image || '/images/blog/default-blog.jpg';
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("article", {
        className: `BlogCard ${className}`,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
            href: `/blog/${slug}`,
            className: "BlogCard__link",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "BlogCard__image",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                            src: imageUrl,
                            alt: title,
                            fill: true,
                            sizes: "(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw",
                            priority: priority,
                            className: "BlogCard__img"
                        }, void 0, false, {
                            fileName: "[project]/src/components/BlogCard/BlogCard.jsx",
                            lineNumber: 30,
                            columnNumber: 6
                        }, ("TURBOPACK compile-time value", void 0)),
                        categories.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "BlogCard__categories",
                            children: categories.slice(0, 2).map((category, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "BlogCard__category",
                                    children: category
                                }, index, false, {
                                    fileName: "[project]/src/components/BlogCard/BlogCard.jsx",
                                    lineNumber: 43,
                                    columnNumber: 9
                                }, ("TURBOPACK compile-time value", void 0)))
                        }, void 0, false, {
                            fileName: "[project]/src/components/BlogCard/BlogCard.jsx",
                            lineNumber: 41,
                            columnNumber: 7
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/BlogCard/BlogCard.jsx",
                    lineNumber: 29,
                    columnNumber: 5
                }, ("TURBOPACK compile-time value", void 0)),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "BlogCard__content",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "BlogCard__meta",
                            children: [
                                formattedDate && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("time", {
                                    className: "BlogCard__date",
                                    dateTime: date,
                                    children: formattedDate
                                }, void 0, false, {
                                    fileName: "[project]/src/components/BlogCard/BlogCard.jsx",
                                    lineNumber: 56,
                                    columnNumber: 8
                                }, ("TURBOPACK compile-time value", void 0)),
                                author && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "BlogCard__author",
                                    children: author
                                }, void 0, false, {
                                    fileName: "[project]/src/components/BlogCard/BlogCard.jsx",
                                    lineNumber: 61,
                                    columnNumber: 8
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/components/BlogCard/BlogCard.jsx",
                            lineNumber: 54,
                            columnNumber: 6
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                            className: "BlogCard__title",
                            children: title
                        }, void 0, false, {
                            fileName: "[project]/src/components/BlogCard/BlogCard.jsx",
                            lineNumber: 68,
                            columnNumber: 6
                        }, ("TURBOPACK compile-time value", void 0)),
                        (description || excerpt) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "BlogCard__excerpt",
                            children: description || excerpt
                        }, void 0, false, {
                            fileName: "[project]/src/components/BlogCard/BlogCard.jsx",
                            lineNumber: 74,
                            columnNumber: 7
                        }, ("TURBOPACK compile-time value", void 0)),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "BlogCard__footer",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "BlogCard__read-more",
                                children: [
                                    "Čítať ďalej",
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                        className: "BlogCard__arrow",
                                        width: "16",
                                        height: "16",
                                        viewBox: "0 0 16 16",
                                        fill: "none",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                            d: "M8 0L6.59 1.41L12.17 7H0V9H12.17L6.59 14.59L8 16L16 8L8 0Z",
                                            fill: "currentColor"
                                        }, void 0, false, {
                                            fileName: "[project]/src/components/BlogCard/BlogCard.jsx",
                                            lineNumber: 84,
                                            columnNumber: 9
                                        }, ("TURBOPACK compile-time value", void 0))
                                    }, void 0, false, {
                                        fileName: "[project]/src/components/BlogCard/BlogCard.jsx",
                                        lineNumber: 83,
                                        columnNumber: 8
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/components/BlogCard/BlogCard.jsx",
                                lineNumber: 81,
                                columnNumber: 7
                            }, ("TURBOPACK compile-time value", void 0))
                        }, void 0, false, {
                            fileName: "[project]/src/components/BlogCard/BlogCard.jsx",
                            lineNumber: 80,
                            columnNumber: 6
                        }, ("TURBOPACK compile-time value", void 0))
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/components/BlogCard/BlogCard.jsx",
                    lineNumber: 52,
                    columnNumber: 5
                }, ("TURBOPACK compile-time value", void 0))
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/BlogCard/BlogCard.jsx",
            lineNumber: 27,
            columnNumber: 4
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/src/components/BlogCard/BlogCard.jsx",
        lineNumber: 26,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0));
};
const __TURBOPACK__default__export__ = BlogCard;
}),
"[project]/src/components/SEO/JsonLdSchemas.js [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

// src/components/SEO/JsonLdSchemas.js
// JSON-LD схемы для лучшего SEO
// 1. Схема для товара (Product Schema)
__turbopack_context__.s({
    "generateBreadcrumbSchema": ()=>generateBreadcrumbSchema,
    "generateLocalBusinessSchema": ()=>generateLocalBusinessSchema,
    "generateOrganizationSchema": ()=>generateOrganizationSchema,
    "generateProductSchema": ()=>generateProductSchema,
    "generateWebsiteSchema": ()=>generateWebsiteSchema
});
function generateProductSchema(product) {
    if (!product) return null;
    const baseUrl = ("TURBOPACK compile-time value", "https://mobilend.sk") || 'https://mobilend.sk';
    // Рассчитываем цену со скидкой
    const originalPrice = parseFloat(product.price) || 0;
    const discount = parseFloat(product.discount) || 0;
    const currentPrice = discount > 0 ? originalPrice * (1 - discount / 100) : originalPrice;
    // Определяем изображение
    let productImage = null;
    if (product.mainImage) {
        productImage = `${baseUrl}/data/gallery/${product.mainImage}`;
    } else if (product.images && product.images.length > 0 && !product.images[0].startsWith('http')) {
        productImage = `${baseUrl}/data/gallery/${product.images[0]}`;
    }
    const schema = {
        "@context": "https://schema.org/",
        "@type": "Product",
        "name": product.model,
        "description": product.shortInfo || `${product.model} s ${product.memory || 'rôznou'} pamäťou. Kvalitný mobilný telefón s modernou technológiou.`,
        "brand": {
            "@type": "Brand",
            "name": product.modelGroup === "Iphones" ? "Apple" : product.modelGroup.replace(" Galaxy", "") || "Apple"
        },
        "category": "Mobilné telefóny",
        "sku": product.productLink,
        "url": `${baseUrl}/katalog/${product.productLink}`,
        "image": productImage ? [
            productImage
        ] : [],
        // Цена и наличие
        "offers": {
            "@type": "Offer",
            "price": currentPrice.toFixed(2),
            "priceCurrency": "EUR",
            "priceValidUntil": new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
            "availability": "https://schema.org/InStock",
            "url": `${baseUrl}/katalog/${product.productLink}`,
            "seller": {
                "@type": "Organization",
                "name": "Mobilend",
                "url": baseUrl
            }
        },
        // Дополнительные свойства товара
        "additionalProperty": []
    };
    // Добавляем характеристики если есть
    if (product.memory) {
        schema.additionalProperty.push({
            "@type": "PropertyValue",
            "name": "Pamäť",
            "value": product.memory
        });
    }
    if (product.color) {
        schema.additionalProperty.push({
            "@type": "PropertyValue",
            "name": "Farba",
            "value": product.color
        });
    }
    return JSON.stringify(schema);
}
function generateOrganizationSchema() {
    const baseUrl = ("TURBOPACK compile-time value", "https://mobilend.sk") || 'https://mobilend.sk';
    const schema = {
        "@context": "https://schema.org",
        "@type": "Organization",
        "name": "Mobilend",
        "alternateName": "Mobilend.sk",
        "description": "Predajca mobilných telefónov na Slovensku. Široký výber iPhone, Samsung Galaxy a ďalších značiek za najlepšie ceny.",
        "url": baseUrl,
        "logo": `${baseUrl}/images/logo.png`,
        "image": `${baseUrl}/images/og-homepage.jpg`,
        // Контактная информация
        "contactPoint": {
            "@type": "ContactPoint",
            "telephone": "+421919496013",
            "contactType": "customer service",
            "email": "zl.maildesk@gmail.com",
            "availableLanguage": [
                "Slovak"
            ]
        },
        // Адрес
        "address": {
            "@type": "PostalAddress",
            "streetAddress": "Pekná cesta 2459",
            "addressLocality": "Bratislava",
            "addressRegion": "Bratislavský kraj",
            "postalCode": "831 52",
            "addressCountry": "SK"
        },
        // Социальные сети (если есть)
        "sameAs": [],
        // Область деятельности
        "knowsAbout": [
            "mobilné telefóny",
            "smartfóny",
            "iPhone",
            "Samsung Galaxy",
            "elektronika"
        ]
    };
    return JSON.stringify(schema);
}
function generateLocalBusinessSchema() {
    const baseUrl = ("TURBOPACK compile-time value", "https://mobilend.sk") || 'https://mobilend.sk';
    const schema = {
        "@context": "https://schema.org",
        "@type": "ElectronicsStore",
        "name": "Mobilend",
        "description": "Obchod s mobilnými telefónmi v Bratislave. Predaj iPhone, Samsung Galaxy a ďalších značiek.",
        "url": baseUrl,
        "telephone": "+421919496013",
        "email": "zl.maildesk@gmail.com",
        // Адрес и геолокация
        "address": {
            "@type": "PostalAddress",
            "streetAddress": "Pekná cesta 2459",
            "addressLocality": "Bratislava",
            "addressRegion": "Rača",
            "postalCode": "831 52",
            "addressCountry": "SK"
        },
        "geo": {
            "@type": "GeoCoordinates",
            "latitude": "48.198111",
            "longitude": "17.135069"
        },
        // Часы работы (настрой под свои)
        "openingHoursSpecification": [
            {
                "@type": "OpeningHoursSpecification",
                "dayOfWeek": [
                    "Monday",
                    "Tuesday",
                    "Wednesday",
                    "Thursday",
                    "Friday"
                ],
                "opens": "09:00",
                "closes": "18:00"
            },
            {
                "@type": "OpeningHoursSpecification",
                "dayOfWeek": "Saturday",
                "opens": "09:00",
                "closes": "16:00"
            }
        ],
        // Способы оплаты
        "paymentAccepted": [
            "Cash",
            "Credit Card",
            "Bank Transfer"
        ],
        // Область обслуживания
        "areaServed": {
            "@type": "Country",
            "name": "Slovakia"
        },
        // Что продаем
        "hasOfferCatalog": {
            "@type": "OfferCatalog",
            "name": "Mobilné telefóny",
            "itemListElement": [
                {
                    "@type": "Offer",
                    "itemOffered": {
                        "@type": "Product",
                        "name": "iPhone"
                    }
                },
                {
                    "@type": "Offer",
                    "itemOffered": {
                        "@type": "Product",
                        "name": "Samsung Galaxy"
                    }
                }
            ]
        }
    };
    return JSON.stringify(schema);
}
function generateWebsiteSchema() {
    const baseUrl = ("TURBOPACK compile-time value", "https://mobilend.sk") || 'https://mobilend.sk';
    const schema = {
        "@context": "https://schema.org",
        "@type": "WebSite",
        "name": "Mobilend",
        "alternateName": "Mobilend.sk",
        "url": baseUrl,
        "description": "Mobilné telefóny za najlepšie ceny na Slovensku",
        // Поиск по сайту (если есть функция поиска)
        "potentialAction": {
            "@type": "SearchAction",
            "target": {
                "@type": "EntryPoint",
                "urlTemplate": `${baseUrl}/katalog?search={search_term_string}`
            },
            "query-input": "required name=search_term_string"
        },
        // Издатель
        "publisher": {
            "@type": "Organization",
            "name": "Mobilend",
            "url": baseUrl
        }
    };
    return JSON.stringify(schema);
}
function generateBreadcrumbSchema(breadcrumbs) {
    if (!breadcrumbs || breadcrumbs.length === 0) return null;
    const baseUrl = ("TURBOPACK compile-time value", "https://mobilend.sk") || 'https://mobilend.sk';
    const schema = {
        "@context": "https://schema.org",
        "@type": "BreadcrumbList",
        "itemListElement": breadcrumbs.map((crumb, index)=>({
                "@type": "ListItem",
                "position": index + 1,
                "name": crumb.name,
                "item": `${baseUrl}${crumb.url}`
            }))
    };
    return JSON.stringify(schema);
}
}),
"[project]/src/components/SEO/JsonLd.jsx [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

// src/components/SEO/JsonLd.jsx
// Компонент для рендера JSON-LD схем в <head>
__turbopack_context__.s({
    "MultipleJsonLd": ()=>MultipleJsonLd,
    "default": ()=>__TURBOPACK__default__export__
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$components$2f$noop$2d$head$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/components/noop-head.js [app-rsc] (ecmascript)");
;
;
const JsonLd = ({ schema })=>{
    if (!schema) return null;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$components$2f$noop$2d$head$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("script", {
            type: "application/ld+json",
            dangerouslySetInnerHTML: {
                __html: schema
            }
        }, void 0, false, {
            fileName: "[project]/src/components/SEO/JsonLd.jsx",
            lineNumber: 11,
            columnNumber: 4
        }, ("TURBOPACK compile-time value", void 0))
    }, void 0, false, {
        fileName: "[project]/src/components/SEO/JsonLd.jsx",
        lineNumber: 10,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0));
};
const MultipleJsonLd = ({ schemas })=>{
    if (!schemas || schemas.length === 0) return null;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$components$2f$noop$2d$head$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
        children: schemas.map((schema, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("script", {
                type: "application/ld+json",
                dangerouslySetInnerHTML: {
                    __html: schema
                }
            }, index, false, {
                fileName: "[project]/src/components/SEO/JsonLd.jsx",
                lineNumber: 26,
                columnNumber: 5
            }, ("TURBOPACK compile-time value", void 0)))
    }, void 0, false, {
        fileName: "[project]/src/components/SEO/JsonLd.jsx",
        lineNumber: 24,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0));
};
const __TURBOPACK__default__export__ = JsonLd;
}),
"[project]/src/pages/BlogPage/BlogPage.jsx [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

// src/pages/BlogPage/BlogPage.jsx
// Компонент страницы блога
__turbopack_context__.s({
    "default": ()=>__TURBOPACK__default__export__
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$BlogCard$2f$BlogCard$2e$jsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/BlogCard/BlogCard.jsx [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$SEO$2f$JsonLdSchemas$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/SEO/JsonLdSchemas.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$SEO$2f$JsonLd$2e$jsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/SEO/JsonLd.jsx [app-rsc] (ecmascript)");
;
;
;
;
;
const BlogPage = ({ allPosts = [] })=>{
    // Разделяем на featured и обычные статьи
    const featuredPosts = allPosts.filter((post)=>post.featured);
    const regularPosts = allPosts.filter((post)=>!post.featured);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("main", {
        className: "BlogPage",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$SEO$2f$JsonLd$2e$jsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                schema: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$SEO$2f$JsonLdSchemas$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["generateOrganizationSchema"])()
            }, void 0, false, {
                fileName: "[project]/src/pages/BlogPage/BlogPage.jsx",
                lineNumber: 17,
                columnNumber: 4
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$SEO$2f$JsonLd$2e$jsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                schema: (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$SEO$2f$JsonLdSchemas$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["generateBreadcrumbSchema"])([
                    {
                        name: 'Domov',
                        url: '/'
                    },
                    {
                        name: 'Blog',
                        url: '/blog'
                    }
                ])
            }, void 0, false, {
                fileName: "[project]/src/pages/BlogPage/BlogPage.jsx",
                lineNumber: 18,
                columnNumber: 4
            }, ("TURBOPACK compile-time value", void 0)),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "container",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("nav", {
                        className: "BlogPage__breadcrumbs",
                        "aria-label": "Breadcrumb",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("ol", {
                            className: "breadcrumb-list",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                    className: "breadcrumb-item",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                        href: "/",
                                        children: "Domov"
                                    }, void 0, false, {
                                        fileName: "[project]/src/pages/BlogPage/BlogPage.jsx",
                                        lineNumber: 28,
                                        columnNumber: 8
                                    }, ("TURBOPACK compile-time value", void 0))
                                }, void 0, false, {
                                    fileName: "[project]/src/pages/BlogPage/BlogPage.jsx",
                                    lineNumber: 27,
                                    columnNumber: 7
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                                    className: "breadcrumb-item active",
                                    "aria-current": "page",
                                    children: "Blog"
                                }, void 0, false, {
                                    fileName: "[project]/src/pages/BlogPage/BlogPage.jsx",
                                    lineNumber: 30,
                                    columnNumber: 7
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/pages/BlogPage/BlogPage.jsx",
                            lineNumber: 26,
                            columnNumber: 6
                        }, ("TURBOPACK compile-time value", void 0))
                    }, void 0, false, {
                        fileName: "[project]/src/pages/BlogPage/BlogPage.jsx",
                        lineNumber: 25,
                        columnNumber: 5
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "BlogPage__header",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                className: "BlogPage__title",
                                children: "Náš Blog"
                            }, void 0, false, {
                                fileName: "[project]/src/pages/BlogPage/BlogPage.jsx",
                                lineNumber: 38,
                                columnNumber: 6
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "BlogPage__subtitle",
                                children: "Najnovšie články, recenzie a tipy o mobilných telefónoch"
                            }, void 0, false, {
                                fileName: "[project]/src/pages/BlogPage/BlogPage.jsx",
                                lineNumber: 39,
                                columnNumber: 6
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/pages/BlogPage/BlogPage.jsx",
                        lineNumber: 37,
                        columnNumber: 5
                    }, ("TURBOPACK compile-time value", void 0)),
                    featuredPosts.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                        className: "BlogPage__featured",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                className: "BlogPage__section-title",
                                children: "Odporúčané články"
                            }, void 0, false, {
                                fileName: "[project]/src/pages/BlogPage/BlogPage.jsx",
                                lineNumber: 47,
                                columnNumber: 7
                            }, ("TURBOPACK compile-time value", void 0)),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "BlogPage__featured-grid",
                                children: featuredPosts.slice(0, 3).map((post, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$BlogCard$2f$BlogCard$2e$jsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                                        post: post,
                                        className: `BlogCard--${index === 0 ? 'large' : 'compact'}`,
                                        priority: index === 0
                                    }, post.slug, false, {
                                        fileName: "[project]/src/pages/BlogPage/BlogPage.jsx",
                                        lineNumber: 50,
                                        columnNumber: 9
                                    }, ("TURBOPACK compile-time value", void 0)))
                            }, void 0, false, {
                                fileName: "[project]/src/pages/BlogPage/BlogPage.jsx",
                                lineNumber: 48,
                                columnNumber: 7
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/pages/BlogPage/BlogPage.jsx",
                        lineNumber: 46,
                        columnNumber: 6
                    }, ("TURBOPACK compile-time value", void 0)),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                        className: "BlogPage__all",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                className: "BlogPage__section-title",
                                children: [
                                    "Všetky články (",
                                    allPosts.length,
                                    ")"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/pages/BlogPage/BlogPage.jsx",
                                lineNumber: 63,
                                columnNumber: 6
                            }, ("TURBOPACK compile-time value", void 0)),
                            allPosts.length > 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "BlogPage__grid",
                                children: allPosts.map((post, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$BlogCard$2f$BlogCard$2e$jsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                                        post: post,
                                        className: "BlogCard--compact",
                                        priority: index < 6
                                    }, post.slug, false, {
                                        fileName: "[project]/src/pages/BlogPage/BlogPage.jsx",
                                        lineNumber: 70,
                                        columnNumber: 9
                                    }, ("TURBOPACK compile-time value", void 0)))
                            }, void 0, false, {
                                fileName: "[project]/src/pages/BlogPage/BlogPage.jsx",
                                lineNumber: 68,
                                columnNumber: 7
                            }, ("TURBOPACK compile-time value", void 0)) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "BlogPage__empty",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                        children: "Zatiaľ nemáme žiadne články"
                                    }, void 0, false, {
                                        fileName: "[project]/src/pages/BlogPage/BlogPage.jsx",
                                        lineNumber: 80,
                                        columnNumber: 8
                                    }, ("TURBOPACK compile-time value", void 0)),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        children: "Čoskoro pridáme zaujímavý obsah o mobilných telefónoch."
                                    }, void 0, false, {
                                        fileName: "[project]/src/pages/BlogPage/BlogPage.jsx",
                                        lineNumber: 81,
                                        columnNumber: 8
                                    }, ("TURBOPACK compile-time value", void 0))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/src/pages/BlogPage/BlogPage.jsx",
                                lineNumber: 79,
                                columnNumber: 7
                            }, ("TURBOPACK compile-time value", void 0))
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/pages/BlogPage/BlogPage.jsx",
                        lineNumber: 62,
                        columnNumber: 5
                    }, ("TURBOPACK compile-time value", void 0))
                ]
            }, void 0, true, {
                fileName: "[project]/src/pages/BlogPage/BlogPage.jsx",
                lineNumber: 23,
                columnNumber: 4
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/src/pages/BlogPage/BlogPage.jsx",
        lineNumber: 15,
        columnNumber: 3
    }, ("TURBOPACK compile-time value", void 0));
};
const __TURBOPACK__default__export__ = BlogPage;
}),
"[project]/src/app/blog/page.js [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

// src/app/blog/page.js
// Главная страница блога - только данные и метаданные
__turbopack_context__.s({
    "default": ()=>Blog,
    "generateMetadata": ()=>generateMetadata,
    "revalidate": ()=>revalidate
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$blog$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/blog.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$pages$2f$BlogPage$2f$BlogPage$2e$jsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/pages/BlogPage/BlogPage.jsx [app-rsc] (ecmascript)");
;
;
;
const revalidate = 3600;
async function generateMetadata() {
    return {
        title: 'Blog - Mobilend | Novinky a tipy o mobilných telefónoch',
        description: 'Najnovšie články o mobilných telefónoch, recenzie, porovnania a tipy. Držte sa v obraze s najnovšími trendmi vo svete smartfónov.',
        keywords: [
            'blog mobilné telefóny',
            'recenzie smartfónov',
            'novinky telefóny',
            'tipy mobilné zariadenia',
            'porovnania telefónov',
            'technológie blog',
            'iPhone články',
            'Samsung blog'
        ],
        // Open Graph
        openGraph: {
            title: 'Blog - Mobilend | Najnovšie o mobilných telefónoch',
            description: 'Prečítajte si najnovšie články o smartfónoch, recenzie a užitočné tipy od expertov na mobilné technológie.',
            type: 'website',
            url: `${("TURBOPACK compile-time value", "https://mobilend.sk") || 'https://mobilend.sk'}/blog`,
            siteName: 'Mobilend',
            locale: 'sk_SK',
            images: [
                {
                    url: `${("TURBOPACK compile-time value", "https://mobilend.sk") || 'https://mobilend.sk'}/images/blog/og-blog.jpg`,
                    width: 1200,
                    height: 630,
                    alt: 'Mobilend Blog - Články o mobilných telefónoch'
                }
            ]
        },
        // Twitter Card
        twitter: {
            card: 'summary_large_image',
            title: 'Blog - Mobilend',
            description: 'Najnovšie články a recenzie mobilných telefónov.',
            images: [
                `${("TURBOPACK compile-time value", "https://mobilend.sk") || 'https://mobilend.sk'}/images/blog/og-blog.jpg`
            ]
        },
        // Robots
        robots: {
            index: true,
            follow: true,
            googleBot: {
                index: true,
                follow: true,
                'max-video-preview': -1,
                'max-image-preview': 'large',
                'max-snippet': -1
            }
        },
        // Canonical URL
        alternates: {
            canonical: '/blog'
        },
        // Dodatočné meta tagy
        other: {
            'theme-color': '#ffffff'
        }
    };
}
async function Blog() {
    // Получаем все статьи блога (ISR - перегенерируется каждый час)
    const allPosts = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$blog$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["getAllBlogPosts"])() // Убираем await
    ;
    // Передаем данные в компонент
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$pages$2f$BlogPage$2f$BlogPage$2e$jsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
        allPosts: allPosts
    }, void 0, false, {
        fileName: "[project]/src/app/blog/page.js",
        lineNumber: 83,
        columnNumber: 9
    }, this);
}
}),
"[project]/src/app/blog/page.js [app-rsc] (ecmascript, Next.js Server Component)": ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/src/app/blog/page.js [app-rsc] (ecmascript)"));
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)": ((__turbopack_context__) => {

var { m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}}),

};

//# sourceMappingURL=%5Broot-of-the-server%5D__b790f7c0._.js.map