module.exports = {

"[project]/.next-internal/server/app/o-nas/page/actions.js [app-rsc] (server actions loader, ecmascript)": ((__turbopack_context__) => {

var { m: module, e: exports } = __turbopack_context__;
{
}}),
"[project]/src/app/favicon.ico.mjs { IMAGE => \"[project]/src/app/favicon.ico (static in ecmascript)\" } [app-rsc] (structured image object, ecmascript, Next.js Server Component)": ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/src/app/favicon.ico.mjs { IMAGE => \"[project]/src/app/favicon.ico (static in ecmascript)\" } [app-rsc] (structured image object, ecmascript)"));
}),
"[project]/src/app/layout.js [app-rsc] (ecmascript, Next.js Server Component)": ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/src/app/layout.js [app-rsc] (ecmascript)"));
}),
"[project]/src/pages/AboutPage/AboutPage.jsx [app-rsc] (client reference proxy) <module evaluation>": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "default": ()=>__TURBOPACK__default__export__
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call the default export of [project]/src/pages/AboutPage/AboutPage.jsx <module evaluation> from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/src/pages/AboutPage/AboutPage.jsx <module evaluation>", "default");
}),
"[project]/src/pages/AboutPage/AboutPage.jsx [app-rsc] (client reference proxy)": ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s({
    "default": ()=>__TURBOPACK__default__export__
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-server-dom-turbopack-server.js [app-rsc] (ecmascript)");
;
const __TURBOPACK__default__export__ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$server$2d$dom$2d$turbopack$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["registerClientReference"])(function() {
    throw new Error("Attempted to call the default export of [project]/src/pages/AboutPage/AboutPage.jsx from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.");
}, "[project]/src/pages/AboutPage/AboutPage.jsx", "default");
}),
"[project]/src/pages/AboutPage/AboutPage.jsx [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$pages$2f$AboutPage$2f$AboutPage$2e$jsx__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/src/pages/AboutPage/AboutPage.jsx [app-rsc] (client reference proxy) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$pages$2f$AboutPage$2f$AboutPage$2e$jsx__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__ = __turbopack_context__.i("[project]/src/pages/AboutPage/AboutPage.jsx [app-rsc] (client reference proxy)");
;
__turbopack_context__.n(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$pages$2f$AboutPage$2f$AboutPage$2e$jsx__$5b$app$2d$rsc$5d$__$28$client__reference__proxy$29$__);
}),
"[project]/src/app/o-nas/page.js [app-rsc] (ecmascript)": ((__turbopack_context__) => {
"use strict";

// src/app/o-nas/page.js
// Страница "О нас" с SEO метаданными
__turbopack_context__.s({
    "default": ()=>Onas,
    "generateMetadata": ()=>generateMetadata
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$pages$2f$AboutPage$2f$AboutPage$2e$jsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/pages/AboutPage/AboutPage.jsx [app-rsc] (ecmascript)");
;
;
async function generateMetadata() {
    return {
        title: 'O nás - Mobilend | Váš partner pre mobilné technológie',
        description: 'Sme váš spoľahlivý partner pre nákup mobilných telefónov. Dlhoročné skúsenosti, kvalita a zákaznícky servis na najvyššej úrovni. Spoznajte našu históriu a hodnoty.',
        keywords: [
            'o nás mobilend',
            'história mobilend',
            'kvalitný servis',
            'mobilné telefóny bratislava',
            'dôveryhodný predajca',
            'zákaznícky servis',
            'skúsenosti predaj telefónov'
        ],
        // Open Graph
        openGraph: {
            title: 'O nás - Mobilend | Kvalita a dôvera',
            description: 'Poznáte nás bližšie. Sme tu pre vás už roky s kvalitným servisom a najlepšími cenami mobilných telefónov.',
            type: 'website',
            url: `${("TURBOPACK compile-time value", "https://mobilend.sk") || 'https://mobilend.sk'}/o-nas`,
            siteName: 'Mobilend',
            locale: 'sk_SK',
            images: [
                {
                    url: `${("TURBOPACK compile-time value", "https://mobilend.sk") || 'https://mobilend.sk'}/images/og.jpg`,
                    width: 1200,
                    height: 630,
                    alt: 'O nás - Mobilend tím'
                }
            ]
        },
        // Twitter Card
        twitter: {
            card: 'summary_large_image',
            title: 'O nás - Mobilend',
            description: 'Váš spoľahlivý partner pre mobilné technológie na Slovensku.',
            images: [
                `${("TURBOPACK compile-time value", "https://mobilend.sk") || 'https://mobilend.sk'}/images/og.jpg`
            ]
        },
        // Robots
        robots: {
            index: true,
            follow: true,
            googleBot: {
                index: true,
                follow: true,
                'max-video-preview': -1,
                'max-image-preview': 'large',
                'max-snippet': -1
            }
        },
        // Canonical URL
        alternates: {
            canonical: '/o-nas'
        },
        // JSON-LD schema pre organizáciu (pridáme nižšie)
        other: {
            'theme-color': '#ffffff'
        }
    };
}
function Onas() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$pages$2f$AboutPage$2f$AboutPage$2e$jsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
        fileName: "[project]/src/app/o-nas/page.js",
        lineNumber: 74,
        columnNumber: 9
    }, this);
}
}),
"[project]/src/app/o-nas/page.js [app-rsc] (ecmascript, Next.js Server Component)": ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/src/app/o-nas/page.js [app-rsc] (ecmascript)"));
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)": ((__turbopack_context__) => {

var { m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}}),

};

//# sourceMappingURL=%5Broot-of-the-server%5D__1069ca9b._.js.map